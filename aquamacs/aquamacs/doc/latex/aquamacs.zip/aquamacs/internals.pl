# LaTeX2HTML 2002-2-1 (1.71)
# Associate internals original text with physical files.


$key = q/buffers.jpg/;
$ref_files{$key} = "$dir".q|node21.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:prefs/;
$ref_files{$key} = "$dir".q|node26.html|; 
$noresave{$key} = "$nosave";

$key = q/aquamacs-tex.jpg/;
$ref_files{$key} = "$dir".q|node27.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:command/;
$ref_files{$key} = "$dir".q|node25.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:shortcuts/;
$ref_files{$key} = "$dir".q|node25.html|; 
$noresave{$key} = "$nosave";

$key = q/aquamacs-screenshot.jpg/;
$ref_files{$key} = "$dir".q|node2.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:terms/;
$ref_files{$key} = "$dir".q|node16.html|; 
$noresave{$key} = "$nosave";

$key = q/theme.jpg/;
$ref_files{$key} = "$dir".q|node26.html|; 
$noresave{$key} = "$nosave";

1;

